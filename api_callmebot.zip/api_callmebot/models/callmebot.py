from odoo import models, fields, api
import requests
import logging
from urllib.parse import quote

_logger = logging.getLogger(__name__)

class CallMeBotIntegration(models.Model):
    _name = 'callmebot.integration'
    _description = 'CallMeBot Integration'

    name = fields.Char(string='Integration Name', required=True)
    phone = fields.Char(string='Phone Number', required=True)
    apikey = fields.Char(string='API Key', required=True)
    message_template = fields.Text(
        string='Message Template',
        required=True,
        help="Use placeholders like {order_id}, {total}, and {customer_name} to customize the message."
    )

    def send_test_message(self):
        """Send a test WhatsApp message."""
        self.ensure_one()
        try:
            if not self.phone or not self.apikey:
                raise ValueError("Phone number or API key is missing.")

            # Test message
            test_message = self.message_template or "This is a test message from Odoo CallMeBot Integration."
            encoded_message = quote(test_message)
            url = f"https://api.callmebot.com/whatsapp.php?phone={self.phone}&text={encoded_message}&apikey={self.apikey}"

            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                _logger.info(f"Test WhatsApp message sent successfully to {self.phone}")
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': 'Success',
                        'message': f"Test message sent successfully to {self.phone}.",
                        'type': 'success',
                        'sticky': False,
                    },
                }
            else:
                _logger.error(f"Failed to send test WhatsApp message: {response.text}")
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': 'Error',
                        'message': f"Failed to send test message: {response.text}",
                        'type': 'danger',
                        'sticky': False,
                    },
                }
        except Exception as e:
            _logger.error(f"Error sending test WhatsApp message: {str(e)}")
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': 'Error',
                    'message': f"Error sending test message: {str(e)}",
                    'type': 'danger',
                    'sticky': False,
                },
            }
