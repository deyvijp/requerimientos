from odoo import models, fields, api
import requests
import logging
from urllib.parse import quote

_logger = logging.getLogger(__name__)

class PosOrder(models.Model):
    _inherit = 'pos.session'

    def _send_whatsapp_message(self, phone, message, apikey):
        """Send a WhatsApp message using CallMeBot API."""
        try:
            encoded_message = quote(message)
            url = f"https://api.callmebot.com/whatsapp.php?phone={phone}&text={encoded_message}&apikey={apikey}"
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                _logger.info(f"WhatsApp message sent successfully to {phone}")
            else:
                _logger.error(f"Failed to send WhatsApp message: {response.text}")
        except Exception as e:
            _logger.error(f"Error sending WhatsApp message: {str(e)}")

    def _create_invoice(self):
        """Override the method to send a WhatsApp message after invoice creation."""
        res = super(PosOrder, self)._create_invoice()
        for order in self:
            # Buscar la configuración de CallMeBot
            integration = self.env['callmebot.integration'].search([], limit=1)
            if integration:
                # Preparar el mensaje
                message = integration.message_template.format(
                    order_id=order.name,
                    total=order.amount_total,
                    customer_name=order.partner_id.name or "Customer"
                )
                # Enviar el mensaje
                self._send_whatsapp_message(integration.phone, message, integration.apikey)
        return res
