{
    "name": "API CallMeBot Integration",
    "version": "1.0",
    "category": "Tools",
    "summary": "Integration with CallMeBot API to send WhatsApp messages.",
    "description": "This module allows you to configure and send WhatsApp messages using the CallMeBot API.",
    "author": "Your Name",
    "website": "https://yourwebsite.com",
    "depends": ["base"],
    "data": [
        "security/ir.model.access.csv",
        "views/callmebot_views.xml"
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}